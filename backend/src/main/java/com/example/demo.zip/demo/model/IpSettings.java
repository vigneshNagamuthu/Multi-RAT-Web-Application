package com.example.demo.model;

public class IpSettings {
    private String if1;
    private String if2;
    private String server;

    // Getters and setters
    public String getIf1() { return if1; }
    public void setIf1(String if1) { this.if1 = if1; }

    public String getIf2() { return if2; }
    public void setIf2(String if2) { this.if2 = if2; }

    public String getServer() { return server; }
    public void setServer(String server) { this.server = server; }
}
